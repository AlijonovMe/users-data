import subprocess

user_id = 1

def get_user_data():
    name = input("Ismingizni kiriting: ")
    lastname = input("Familiyangizni kiriting: ")

    age = input_with_validation("Yoshingizni kiriting: ", is_age_valid)
    phone = input_with_validation("Telefon raqamingizni kiriting: ", is_phone_valid)
    email = input_with_validation("Email manzilingizni kiriting: ", is_email_valid)
    address = input("Manzilingizni kiriting: ")

    return name, lastname, int(age), phone, email, address

def input_with_validation(prompt, validation_func):
    while True:
        user_input = input(prompt)
        if validation_func(user_input):
            return user_input
        print("Noto'g'ri ma'lumot, qayta kiriting.")

def is_age_valid(age):
    return age.isdigit()

def is_phone_valid(phone):
    return phone.startswith("+998") and len(phone) == 13

def is_email_valid(email):
    return "@" in email and "." in email

def save_user_data(user_id, name, lastname, age, phone, email, address):
    with open("users_info.txt", "a") as file:
        file.write(f"\nID: {user_id}\nName: {name}\nLastname: {lastname}\nAge: {age}\nPhone: {phone}\nEmail: {email}\nAddress: {address}\n")

def git_push():
    try:
        subprocess.run(["git", "add", "users_info.txt"], check=True)
        subprocess.run(["git", "commit", "-m", f"Yangi foydalanuvchi ma'lumotlari qo'shildi: ID {user_id}"], check=True)
        subprocess.run(["git", "push"], check=True)
        print("Ma'lumotlar GitHub'ga muvaffaqiyatli yuklandi!")
    except subprocess.CalledProcessError:
        print("Git push jarayonida xatolik yuz berdi.")

while True:
    user_data = get_user_data()
    save_user_data(user_id, *user_data)
    print("Ma'lumotlar muvaffaqiyatli saqlandi!\n")
    git_push()
    user_id += 1
